<footer class="bg-soft-primary pt-5" id="footer">
  <div class="container pb-4 text-center">
    <div class="row mt-n10 mt-lg-0">
      <div class="col-xl-12 mx-auto">
        <!--/.row -->
        <p class="text-center"> {{__('All rights received')}} © {{date('Y')}}</a></p>

        <!-- /.social -->
      </div>
      <!-- /column -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container -->
</footer>
