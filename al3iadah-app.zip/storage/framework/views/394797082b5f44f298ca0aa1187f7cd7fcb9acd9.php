<?php if(auth()->guard()->check()): ?>
<script type="text/javascript" src="/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="/js/tinymce/ar.js"></script>
<?php endif; ?>
<script type="module">
<?php if(auth()->check()): ?>

    tinymce.init({
        selector: '.editor,#editor',
        plugins: ' advlist autolink directionality table wordcount link lists numlist bullist',
        directionality : '<?php echo e(app()->getLocale() == "ar" ? "rtl" : "ltr"); ?>',
        language:'<?php echo e(app()->getLocale()); ?>',
        quickbars_selection_toolbar: 'bold italic |h1 h2 h3 h4 h5 h6| formatselect | quicklink blockquote | numlist bullist',
        entity_encoding : "raw",
        verify_html : false 
    });
<?php else: ?> 
/* Guest Js */


<?php endif; ?>

 toastr.options = {
        closeButton: true,
        debug: false,
        onclick: null,
        showDuration: 300,
        hideDuration: 1000,
        extendedTimeOut: 1000,
        showEasing: 'swing',
        hideEasing: 'linear',
        showMethod: 'fadeIn',
        hideMethod: 'fadeOut',
        progressBar:true,
        preventDuplicates:true,
        newestOnTop:true,
        positionClass: '<?php echo e(app()->getLocale() == "ar" ? "toast-top-left" : "toast-top-right"); ?>',
        timeOut:10000
    }

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

   

</script>
<?php /**PATH /Users/dragon/Code/clinic/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>