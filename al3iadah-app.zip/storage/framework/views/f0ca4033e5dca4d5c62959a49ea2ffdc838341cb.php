<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form>

<div class="col-12 fixed-top  main-nav shadow" style="background: #fff;padding: 3px 0px;min-height: 65px;">
    <div class="container px-1 my-auto">
        <div class="col-12 row p-0">
            <div class="col-auto p-3 d-flex align-items-center hover-main-color-flexable" onclick="document.getElementById('aside-menu').classList.toggle('active');document.getElementById('body-overlay').classList.toggle('active');" style="cursor: pointer;">
                <span class="far fa-bars font-3 px-0"></span>
            </div>
        
            <div class="col me-auto p-0 row justify-content-between d-flex">
                <div class="col row m-0 px-2">
                </div>

                 <div class="col-12 px-0 d-flex justify-content-center align-items-center dropdown"
                        style="width: 55px;height: 55px;">
                    <div style="width: 55px;height: 55px;cursor: pointer;" data-bs-toggle="dropdown"
                        aria-expanded="false"
                        class="d-flex justify-content-center align-items-center cursor-pointer">
                        <i class="fi fi-<?php echo e(config('core.locale.languages')[app()->getLocale()]['flag']); ?> font-2"></i>
                    </div>
                    <?php if(config('core.locale.languages') && count(config('core.locale.languages')) > 1 ): ?>
                    <ul class="dropdown-menu shadow border-0" aria-labelledby="dropdownMenuButton1"
                        style="top: -3px;">
                        <?php $__currentLoopData = collect(config('core.locale.languages'))->sortBy('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($code !== app()->getLocale()): ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.utils.link','data' => ['class' => 'dropdown-item pt-1 pb-1','href' => route('locale.change', $code),'text' => __(\App\Helpers\MainHelper::getLocaleName($code)),'icon' => 'fi fi-'.e($details['flag']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('utils.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'dropdown-item pt-1 pb-1','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('locale.change', $code)),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__(\App\Helpers\MainHelper::getLocaleName($code))),'icon' => 'fi fi-'.e($details['flag']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/dragon/Code/clinic/resources/views/components/navbar.blade.php ENDPATH**/ ?>