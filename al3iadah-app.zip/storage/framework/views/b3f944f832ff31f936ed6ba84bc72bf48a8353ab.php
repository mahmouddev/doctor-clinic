<?php $__env->startSection('content'); ?>

<div class="col-12 p-3 row">

	<div class="col-12 col-sm-6 col-lg-3 col-xl-3 col-xxl-2 px-2 my-2">
		<div class="col-12 px-0 py-1 d-flex main-box-wedit" >
			<div style="width: 65px;" class="p-2">
				<div class="col-12 px-0 text-center d-flex align-items-center justify-content-center" style="background: #0194fe;color: #fff;border-radius: 50%;width: 55px;height:55px">
					<span class="fal fa-users fa-2x" ></span>
				</div>
			</div>
			<div style="width: calc(100% - 80px)" class="px-2 py-2">
				<a class="font-1"  href="<?php echo e(route('admin.clinic.patients.index')); ?>" style="color: #212529">
					<?php echo e(__('Patients')); ?>

					<h6 class="font-3 pt-2"><?php echo e(\App\Models\Patient::count()); ?></h6>
				</a>
			</div>
		</div>
	</div>

	<div class="col-12 col-sm-6 col-lg-3 col-xl-3 col-xxl-2 px-2 my-2">
		<div class="col-12 px-0 py-1 d-flex main-box-wedit" >
			<div style="width: 65px;" class="p-2">
				<div class="col-12 px-0 text-center d-flex align-items-center justify-content-center" style="background: #0194fe;color: #fff; border-radius: 50%;width: 55px;height:55px">
					<span class="fal fa-calendar-check fa-2x" ></span>
				</div>
			</div>
			<div style="width: calc(100% - 80px)" class="px-2 py-2">
				<a class="font-1" href="" style="color: #212529">
					<?php echo e(__('Appointments')); ?>

					<h6 class="font-3  pt-2"><?php echo e(\App\Models\Invoice::count()); ?></h6>
				</a>
			</div>
		</div>
	</div>

	<div class="col-12 col-sm-6 col-lg-3 col-xl-3 col-xxl-2 px-2 my-2">
		<div class="col-12 px-0 py-1 d-flex main-box-wedit" >
			<div style="width: 65px;" class="p-2">
				<div class="col-12 px-0 text-center d-flex align-items-center justify-content-center" style="background: #0194fe;color: #fff; border-radius: 50%;width: 55px;height:55px">
					<span class="fal fa-file-invoice fa-2x" ></span>
				</div>
			</div>
			<div style="width: calc(100% - 80px)" class="px-2 py-2">
				<a class="font-1" href="" style="color: #212529;">
					<?php echo e(__('Total revenue')); ?>

					<h6 class="font-3 pt-2"><?php echo e(\App\Models\Invoice::sum('total_price')); ?></h6>
				</a>
			</div>
		</div>
	</div>

	<div class="col-12 col-sm-6 col-lg-3 col-xl-3 col-xxl-2 px-2 my-2">
		<div class="col-12 px-0 py-1 d-flex main-box-wedit" >
			<div style="width: 65px;" class="p-2">
				<div class="col-12 px-0 text-center d-flex align-items-center justify-content-center" style="background: #0194fe;color: #fff; border-radius: 50%;width: 55px;height:55px">
					<span class="fal fa-file-prescription fa-2x" ></span>
				</div>
			</div>
			<div style="width: calc(100% - 80px)" class="px-2 py-2">
				<a class="font-1" href="<?php echo e(route('admin.clinic.prescriptions.index')); ?>" style="color: #212529;">
					<?php echo e(__('Prescriptions')); ?>

					<h6 class="font-3 pt-2"><?php echo e(\App\Models\Prescription::count()); ?></h6>
				</a>
			</div>
		</div>
	</div>

	<div class="col-12 px-2 py-2">
		<div style="height: 4px ;background: rgb(118 169 169);border-radius: 7px;transition: width .5s ease-in-out;width: 0%;" id="home-dashboard-divider"></div>
	</div>
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard-statistics', [])->html();
} elseif ($_instance->childHasBeenRendered('Q5Dmi9u')) {
    $componentId = $_instance->getRenderedChildComponentId('Q5Dmi9u');
    $componentTag = $_instance->getRenderedChildComponentTagName('Q5Dmi9u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Q5Dmi9u');
} else {
    $response = \Livewire\Livewire::mount('dashboard-statistics', []);
    $html = $response->html();
    $_instance->logRenderedChild('Q5Dmi9u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dragon/Code/clinic/resources/views/admin/index.blade.php ENDPATH**/ ?>