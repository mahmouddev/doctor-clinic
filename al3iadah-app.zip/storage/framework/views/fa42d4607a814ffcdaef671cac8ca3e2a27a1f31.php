<footer class="bg-soft-primary pt-5" id="footer">
  <div class="container pb-4 text-center">
    <div class="row mt-n10 mt-lg-0">
      <div class="col-xl-12 mx-auto">
        <!--/.row -->
        <p class="text-center"> <?php echo e(__('All rights received')); ?> © <?php echo e(date('Y')); ?></a></p>

        <!-- /.social -->
      </div>
      <!-- /column -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container -->
</footer>
<?php /**PATH /Users/dragon/Code/clinic/resources/views/components/footer.blade.php ENDPATH**/ ?>