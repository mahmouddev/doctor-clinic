<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

interface InstallerRepository extends RepositoryInterface
{

}
