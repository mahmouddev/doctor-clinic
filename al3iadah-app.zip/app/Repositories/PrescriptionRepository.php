<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PrescriptionRepository.
 *
 * @package namespace App\Repositories;
 */
interface PrescriptionRepository extends RepositoryInterface
{
    //
}
