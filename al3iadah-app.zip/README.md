# clinic

clinic is online food & resturants orders mangment software designed for small and meduim businesses. It is built with modern technologies such as Laravel, VueJS, Bootstrap 5, clinic provides an awesome App Store for users and developers.

## Requirements

* PHP 8.0.2 or higher
* Database (eg: MySQL, PostgreSQL, SQLite)
* Web Server (eg: Apache, Nginx, IIS)

## Framework

clinic uses [Laravel](http://laravel.com), the best existing PHP framework, as the foundation framework.

## Installation

* Install [Composer](https://getcomposer.org/download)
* Install dependencies: `composer install`
* Install clinic:
    * `php artisan migrate`
    * `php artisan db:seed`
    * `php artisan storage:link`

